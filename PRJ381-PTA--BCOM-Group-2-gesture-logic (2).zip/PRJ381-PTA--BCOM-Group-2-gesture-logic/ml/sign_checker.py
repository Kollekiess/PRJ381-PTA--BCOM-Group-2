"""
ml/sign_checker.py  -  decides when the learner has COMPLETED the target sign (a letter OR a word).
 
Give it the target and, every camera frame, the hand data. It tells you what happened:
  event = None       nothing finished yet (keep going)
  event = "correct"  the learner completed the target sign
  event = "wrong"    the learner completed a sign, but not the target
 
How "completed" is decided
  LETTER (a still hand shape): the model must name the target letter with enough confidence
         and the learner must HOLD it steady for about 1 second.
  WORD (a movement):  recording starts when a hand appears and ends when the hands are lowered
         for a moment (or after 5 seconds). The finished movement is classified once.
         In VR the hands never disappear, so the headset app must end a word differently
         (see HANDOFF notes): a countdown window, or a "hands down" position.
"""
 
from ml.accumulator import LetterAccumulator
from ml.sequences import frame_vector  # noqa: F401  (re-exported for convenience)
from ml.word_model import classify_clip
from ml.word_segmenter import WordSegmenter
 
WORD_STATES = {
    "ready": "Do the sign, then lower your hands",
    "recording": "Recording... lower your hands when you finish",
    "lower hands": "Lower your hands",
}
 
 
class SignChecker:
    def __init__(self, letter_engine, word_model=None, word_labels=None,
                 hold_seconds=1.0, word_min_conf=0.6):
        self.engine = letter_engine
        self.word_model = word_model
        self.word_labels = word_labels or []
        self.hold_seconds = hold_seconds
        self.word_min_conf = word_min_conf
        self.target = None
        self.set_target(None)
 
    def kind(self, target):
        return "letter" if target in self.engine.labels else "word"
 
    def set_target(self, target):
        """Call this whenever the learner is asked for a new sign."""
        self.target = target.upper() if target else None
        self.acc = LetterAccumulator(self.hold_seconds, self.engine.min_confidence)
        self.seg = WordSegmenter()
 
    def update(self, hand63, vec126, now):
        """hand63: flattened landmarks (63 numbers) of the first hand, or None if no hand.
        vec126: both hands from ml.sequences.frame_vector(poses). now: time in seconds."""
        if self.target is None:
            raise ValueError("call set_target() first")
        if self.kind(self.target) == "letter":
            return self._letter(hand63, now)
        return self._word(vec126, now)
 
    # ---------------- letters ----------------
    def _letter(self, hand63, now):
        res = self.engine.evaluate(self.target, hand63) if hand63 is not None else None
        letter = res.predicted if res else None
        conf = res.confidence if res else 0.0
        accepted, progress = self.acc.update(letter, conf, now)
        out = dict(kind="letter", event=None, state="Hold the sign steady", progress=progress,
                   predicted=letter, confidence=conf, message="",
                   hint=res.hint if (res and not res.correct) else "")
        if accepted == self.target:
            out.update(event="correct", message="Correct!", hint="")
        elif accepted:
            out.update(event="wrong", message=res.message)
        return out
 
    # ---------------- words ----------------
    def _word(self, vec126, now):
        if self.word_model is None:
            raise RuntimeError("No word model loaded. Run train_sequence.py first.")
        clip = self.seg.update(vec126, now)
        out = dict(kind="word", event=None, state=WORD_STATES[self.seg.state], progress=0.0,
                   predicted=None, confidence=0.0, message="", hint="")
        if clip is None:
            return out
        best, conf = classify_clip(self.word_model, self.word_labels, clip)[0]
        out.update(predicted=best, confidence=conf)
        if best == self.target and conf >= self.word_min_conf:
            out.update(event="correct", message="Correct!")
        elif best == "IDLE" or conf < self.word_min_conf:
            out.update(event="wrong", message=f"Not sure that was {self.target}. Try again.")
        else:
            out.update(event="wrong", message=f"That looked like {best}, not {self.target}.")
        return out