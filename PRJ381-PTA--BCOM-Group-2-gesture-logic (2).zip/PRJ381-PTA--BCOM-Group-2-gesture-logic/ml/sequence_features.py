import numpy as np
 
SEQ_LEN = 30
FEATURES = 90
AUG_COPIES = 6
 
 
def clip_to_features(clip):
    clip = np.asarray(clip, dtype=np.float32)
    T = clip.shape[0]
    pts_all = clip.reshape(T, 2, 21, 3)[..., :2]
    present = np.abs(clip.reshape(T, 2, 63)).sum(axis=2) > 0
    out = np.zeros((T, 2, 45), dtype=np.float32)
    for t in range(T):
        for h in range(2):
            if not present[t, h]:
                continue
            pts = pts_all[t, h]
            wrist = pts[0].copy()
            rel = pts - wrist
            scale = np.linalg.norm(rel[9])
            if scale < 1e-6:
                scale = 1.0
            out[t, h, :42] = (rel / scale).flatten()
            out[t, h, 42:44] = wrist
            out[t, h, 44] = 1.0
    return out.reshape(T, FEATURES)
 
 
def mirror_features(F):
    """The same sign done by a left-handed signer: swap the hands and flip left/right."""
    M = np.asarray(F, dtype=np.float32).reshape(-1, 2, 45)[:, ::-1, :].copy()
    present = M[:, :, 44] > 0
    shape = M[:, :, :42].reshape(-1, 2, 21, 2).copy()
    shape[..., 0] *= -1
    M[:, :, :42] = shape.reshape(-1, 2, 42)
    M[:, :, 42] = np.where(present, 1.0 - M[:, :, 42], 0.0)
    return M.reshape(-1, FEATURES)
 
 
def augment(F, rng):
    """A slightly different copy: a little noise on the hand shape, and the whole sign shifted a bit."""
    A = np.asarray(F, dtype=np.float32).reshape(-1, 2, 45).copy()
    present = (A[:, :, 44] > 0)[..., None]
    A[:, :, :42] += rng.normal(0, 0.01, A[:, :, :42].shape).astype(np.float32) * present
    shift = rng.normal(0, 0.03, (1, 1, 2)).astype(np.float32)
    A[:, :, 42:44] += shift * present
    return A.reshape(-1, FEATURES)
 