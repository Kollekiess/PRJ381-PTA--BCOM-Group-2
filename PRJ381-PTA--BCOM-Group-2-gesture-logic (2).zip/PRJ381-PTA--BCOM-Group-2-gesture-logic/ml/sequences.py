import numpy as np
 
SEQ_LEN = 30          # every clip is resampled to this many frames
MIN_HAND_FRAMES = 8   # a clip with fewer frames containing a hand is rejected
 
 
def frame_vector(poses):
    """Turn the HandPose list for ONE frame into a 126-number vector.
    Two hands visible: the one further left in the picture goes in the LEFT slot (this does not
    rely on MediaPipe's left/right label, which can be wrong). One hand: its label picks the slot."""
    vec = np.zeros(126, dtype=np.float32)
    if len(poses) >= 2:
        two = sorted(poses[:2], key=lambda p: p.landmarks[0].x)
        for slot, pose in enumerate(two):
            vec[slot * 63:(slot + 1) * 63] = pose.flattened_landmarks()
    elif len(poses) == 1:
        slot = 0 if poses[0].handedness == "Left" else 1
        vec[slot * 63:(slot + 1) * 63] = poses[0].flattened_landmarks()
    return vec
 
 
def trim_empty_ends(frames):
    """Drop leading/trailing frames where no hand was visible."""
    has_hand = [bool(np.any(f)) for f in frames]
    if not any(has_hand):
        return []
    first = has_hand.index(True)
    last = len(has_hand) - 1 - has_hand[::-1].index(True)
    return frames[first:last + 1]
 
 
def resample(frames, length=SEQ_LEN):
    """Pick `length` evenly spaced frames, so slow and fast signers give equal-length clips."""
    idx = np.linspace(0, len(frames) - 1, length).round().astype(int)
    return np.stack([frames[i] for i in idx])
 