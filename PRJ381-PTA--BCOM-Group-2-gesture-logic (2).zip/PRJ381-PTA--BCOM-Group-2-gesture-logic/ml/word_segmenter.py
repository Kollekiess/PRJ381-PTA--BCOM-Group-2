import numpy as np
 
from ml.sequences import MIN_HAND_FRAMES, SEQ_LEN, resample, trim_empty_ends
 
 
class WordSegmenter:
    def __init__(self, gap_seconds=0.7, max_seconds=5.0, min_hand_frames=MIN_HAND_FRAMES):
        self.gap_seconds = gap_seconds
        self.max_seconds = max_seconds
        self.min_hand_frames = min_hand_frames
        self.frames, self.recording, self.blocked = [], False, False
        self.start = self.last_hand = 0.0
 
    @property
    def state(self):
        return "recording" if self.recording else ("lower hands" if self.blocked else "ready")
 
    def update(self, vec, now):
        """vec: 126 numbers for this frame (zeros = no hand). Returns a (30,126) clip when a sign
        has just finished, otherwise None."""
        has = bool(np.any(vec))
        if self.blocked:                     # a sign was cut off for being too long: wait for hands down
            if not has:
                self.blocked = False
            return None
        if not self.recording:
            if has:
                self.recording, self.frames = True, [vec]
                self.start = self.last_hand = now
            return None
 
        self.frames.append(vec)
        if has:
            self.last_hand = now
        too_long = now - self.start >= self.max_seconds
        ended = now - self.last_hand >= self.gap_seconds
        if not (ended or too_long):
            return None
        if too_long and not ended:
            self.blocked = True
        return self._finish()
 
    def _finish(self):
        frames = trim_empty_ends(self.frames)
        hand_frames = sum(1 for f in frames if np.any(f))
        self.recording, self.frames = False, []
        if not frames or hand_frames < self.min_hand_frames:
            return None
        return resample(frames, SEQ_LEN)
 