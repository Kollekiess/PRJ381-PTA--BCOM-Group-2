import json
import os
 
import numpy as np
import tensorflow as tf
 
from ml.sequence_features import clip_to_features
 
MODEL_FILE = os.path.join("models", "sasl_words_model.keras")
LABELS_FILE = os.path.join("models", "sasl_words_labels.json")
 
 
def load_word_model():
    model = tf.keras.models.load_model(MODEL_FILE)
    with open(LABELS_FILE) as f:
        labels = json.load(f)
    return model, labels
 
 
def classify_clip(model, labels, clip, top_k=3):
    """clip: (30,126) raw clip. Returns [(word, probability), ...] best first."""
    feats = clip_to_features(clip)[None].astype("float32")
    probs = model(feats, training=False).numpy()[0]
    order = np.argsort(probs)[::-1][:top_k]
    return [(labels[i], float(probs[i])) for i in order]
 