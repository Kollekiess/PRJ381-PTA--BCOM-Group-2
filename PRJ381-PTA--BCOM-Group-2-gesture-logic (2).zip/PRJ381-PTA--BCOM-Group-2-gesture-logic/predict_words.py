import os
import sys
import time
 
import cv2
 
from ml.sequences import frame_vector
from ml.word_model import classify_clip, load_word_model
from ml.word_segmenter import WordSegmenter
from tracking.hand_tracker import HandTracker
 
MIN_CONFIDENCE = 0.6
SHOW_RESULT_SECONDS = 4
 
 
def main():
    target = sys.argv[1].upper() if len(sys.argv) > 1 else None
    if not os.path.isfile(os.path.join("models", "sasl_words_model.keras")):
        print("No word model yet. Record clips with collect_sequence.py, then run train_sequence.py.")
        return
    model, labels = load_word_model()
 
    tracker = HandTracker()
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam.")
        return
 
    seg = WordSegmenter()
    result, result_until, timestamp = None, 0.0, 0
 
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        poses = tracker.detect(rgb, timestamp)
        timestamp += 33
        h, w, _ = frame.shape
        now = time.time()
 
        for pose in poses:
            for lm in pose.landmarks:
                cv2.circle(frame, (int(lm.x * w), int(lm.y * h)), 4, (0, 255, 0), -1)
 
        clip = seg.update(frame_vector(poses), now)
        if clip is not None:
            result, result_until = classify_clip(model, labels, clip), now + SHOW_RESULT_SECONDS
 
        if seg.state == "recording":
            cv2.circle(frame, (w - 30, 30), 12, (0, 0, 255), -1)
            status = "Recording... lower your hands when you finish"
        elif seg.state == "lower hands":
            status = "Lower your hands"
        else:
            status = "Ready: do a sign, then lower your hands"
        if target:
            cv2.putText(frame, f"Target: {target}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 255), 2)
        cv2.putText(frame, status, (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
 
        if result and now < result_until:
            best, conf = result[0]
            if best == "IDLE" and conf >= MIN_CONFIDENCE:
                line, color = "No sign recognised", (255, 255, 255)      # the 'IDLE' class = hands just moving
            elif conf >= MIN_CONFIDENCE:
                line, color = f"{best}  {conf:.0%}", (0, 255, 0)
                if target:
                    line += "  Correct!" if best == target else "  Not quite"
                    color = (0, 255, 0) if best == target else (0, 165, 255)
            else:
                line, color = f"Not sure (maybe {best} {conf:.0%})", (0, 165, 255)
            cv2.putText(frame, line, (10, h - 50), cv2.FONT_HERSHEY_SIMPLEX, 1.1, color, 3)
            others = "   ".join(f"{n} {p:.0%}" for n, p in result[1:])
            cv2.putText(frame, others, (10, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.imshow("BCSignVR - words", frame)
 
        if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
            break
 
    cap.release()
    cv2.destroyAllWindows()
 
 
if __name__ == "__main__":
    main()
 