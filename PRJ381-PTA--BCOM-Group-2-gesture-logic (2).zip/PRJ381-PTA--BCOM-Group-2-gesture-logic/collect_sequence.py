import glob
import os
import sys
import time
 
import cv2
import numpy as np
 
from ml.sequences import MIN_HAND_FRAMES, SEQ_LEN, frame_vector, resample, trim_empty_ends
from tracking.hand_tracker import HandTracker
 
COUNTDOWN_SECONDS = 3
MAX_RECORD_SECONDS = 4
 
 
def main():
    if len(sys.argv) < 2:
        print("Usage: python collect_sequence.py <SIGN_NAME>   e.g. python collect_sequence.py HELLO")
        return
    label = sys.argv[1].upper()
 
    folder = os.path.join("data", "sequences", label)
    os.makedirs(folder, exist_ok=True)
    saved = sorted(glob.glob(os.path.join(folder, "clip_*.npy")))
    next_number = len(saved)
 
    tracker = HandTracker()
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam. Is another app using it?")
        return
 
    state = "READY"          # READY -> COUNTDOWN -> RECORDING -> READY
    state_start = 0.0
    frames = []
    message = ""
    timestamp = 0
    print(f"Recording sign '{label}'. SPACE = start/stop, D = delete last, Q = quit.")
 
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        poses = tracker.detect(rgb, timestamp)
        timestamp += 33
        h, w, _ = frame.shape
 
        for pose in poses:
            for lm in pose.landmarks:
                cv2.circle(frame, (int(lm.x * w), int(lm.y * h)), 4, (0, 255, 0), -1)
 
        now = time.time()
        stop_now = False
 
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        elif key == ord(" "):
            if state == "READY":
                state, state_start, message = "COUNTDOWN", now, ""
            elif state == "RECORDING":
                stop_now = True
        elif key == ord("d") and state == "READY" and saved:
            os.remove(saved.pop())
            next_number = len(saved)
            message = "Last clip deleted"
            print("Deleted last clip")
 
        if state == "COUNTDOWN":
            remaining = COUNTDOWN_SECONDS - (now - state_start)
            if remaining <= 0:
                state, state_start, frames = "RECORDING", now, []
            else:
                cv2.putText(frame, str(int(remaining) + 1), (w // 2 - 30, h // 2 + 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 4, (0, 255, 255), 8)
 
        if state == "RECORDING":
            frames.append(frame_vector(poses))
            cv2.circle(frame, (w - 30, 30), 12, (0, 0, 255), -1)
            if now - state_start >= MAX_RECORD_SECONDS:
                stop_now = True
 
        if stop_now:
            clip_frames = trim_empty_ends(frames)
            hand_frames = sum(1 for f in clip_frames if np.any(f))
            if len(clip_frames) == 0 or hand_frames < MIN_HAND_FRAMES:
                message = "Rejected: hands not visible enough - try again"
            else:
                clip = resample(clip_frames, SEQ_LEN)
                path = os.path.join(folder, f"clip_{next_number:03d}.npy")
                np.save(path, clip)
                saved.append(path)
                next_number += 1
                message = f"Saved clip {len(saved)}"
                print(f"Saved clip {len(saved)} for '{label}'")
            state = "READY"
 
        cv2.putText(frame, f"Sign: {label}   Clips: {len(saved)}   [{state}]", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, "SPACE start/stop  D delete last  Q quit", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
        if message:
            cv2.putText(frame, message, (10, h - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        cv2.imshow("BCSignVR - recording signs", frame)
 
    cap.release()
    cv2.destroyAllWindows()
    print(f"Done. {len(saved)} clips saved for '{label}' in {folder}")
 
 
if __name__ == "__main__":
    main()