"""
practice_all.py  -  a mini lesson with LETTERS AND WORDS mixed together.
 
Usage (from the project root, after train.py and train_sequence.py):
    python practice_all.py                  # 10 random targets, letters and words mixed
    python practice_all.py A B HELLO        # only these targets
 
For a LETTER: hold the shape steady for about a second.
For a WORD:   do the sign (one or two hands), then LOWER YOUR HANDS.
Correct -> tick and the next target. Wrong -> it says what it saw. 25 seconds -> skipped.
Keys: S = skip,  Q / ESC = finish.  The session is saved to data/sessions.csv.
"""
 
import csv
import os
import random
import sys
import time
from datetime import datetime
 
import cv2
 
from ml.feedback import FeedbackEngine
from ml.sequences import frame_vector
from ml.sign_checker import SignChecker
from ml.word_model import load_word_model
from tracking.hand_tracker import HandTracker
 
ROUNDS = 10
ROUND_TIMEOUT = 25
SESSIONS_FILE = os.path.join("data", "sessions.csv")
 
 
def save_session(rounds_done, correct, skipped, mistakes, seconds):
    os.makedirs("data", exist_ok=True)
    new = not os.path.isfile(SESSIONS_FILE) or os.path.getsize(SESSIONS_FILE) == 0
    with open(SESSIONS_FILE, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["date", "rounds", "correct", "skipped", "mistakes",
                        "accuracy_percent", "duration_seconds"])
        acc = round(100 * correct / rounds_done, 1) if rounds_done else 0
        w.writerow([datetime.now().strftime("%Y-%m-%d %H:%M"), rounds_done, correct,
                    skipped, mistakes, acc, round(seconds)])
 
 
def main():
    engine = FeedbackEngine()
    word_model, word_labels = (None, [])
    if os.path.isfile(os.path.join("models", "sasl_words_model.keras")):
        word_model, word_labels = load_word_model()
    words = [w for w in word_labels if w != "IDLE"]
 
    pool = [a.upper() for a in sys.argv[1:]] or (engine.labels + words)
    pool = [t for t in pool if t in engine.labels or t in words]
    if not pool:
        print("None of those targets are trained.")
        return
    print(f"Letters: {len(engine.labels)}   Words: {words if words else 'none (run train_sequence.py)'}")
 
    checker = SignChecker(engine, word_model, word_labels)
    tracker = HandTracker()
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam.")
        return
 
    def new_target(previous=None):
        letters = [t for t in pool if t in engine.labels and t != previous]
        wds = [t for t in pool if t not in engine.labels and t != previous]
        if letters and wds:                       # mix: roughly half letters, half words
            return random.choice(wds if random.random() < 0.5 else letters)
        return random.choice(letters or wds or pool)
 
    target = new_target()
    checker.set_target(target)
    round_start = session_start = time.time()
    rounds_done = correct = skipped = mistakes = 0
    flash, flash_color, flash_until = "", (255, 255, 255), 0.0
    timestamp, finished = 0, False
    info = {"kind": "letter", "state": "", "progress": 0.0, "hint": ""}
 
    def next_round():
        nonlocal target, round_start, rounds_done
        rounds_done += 1
        target = new_target(target)
        checker.set_target(target)
        round_start = time.time()
 
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        poses = tracker.detect(rgb, timestamp)
        timestamp += 33
        h, w, _ = frame.shape
        now = time.time()
 
        if not finished:
            for pose in poses:
                for lm in pose.landmarks:
                    cv2.circle(frame, (int(lm.x * w), int(lm.y * h)), 4, (0, 255, 0), -1)
            hand63 = poses[0].flattened_landmarks() if poses else None
            info = checker.update(hand63, frame_vector(poses), now)
 
            if info["event"] == "correct":
                correct += 1
                flash, flash_color, flash_until = "Correct!", (0, 255, 0), now + 1.2
                next_round()
            elif info["event"] == "wrong":
                mistakes += 1
                flash, flash_color, flash_until = info["message"], (0, 165, 255), now + 2.5
                checker.set_target(target)         # try again at the same target
            elif now - round_start > ROUND_TIMEOUT:
                skipped += 1
                flash, flash_color, flash_until = f"Skipped {target}", (0, 0, 255), now + 1.5
                next_round()
 
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                finished = True
            elif key == ord("s"):
                skipped += 1
                next_round()
            if rounds_done >= ROUNDS:
                finished = True
 
            kind = "Letter" if target in engine.labels else "Word"
            cv2.putText(frame, f"{kind}:  {target}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (0, 255, 255), 3)
            cv2.putText(frame, f"Round {min(rounds_done + 1, ROUNDS)}/{ROUNDS}   Correct: {correct}   "
                               f"Mistakes: {mistakes}", (10, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            cv2.putText(frame, info["state"], (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            if info["kind"] == "letter":
                cv2.rectangle(frame, (10, 125), (210, 139), (255, 255, 255), 1)
                cv2.rectangle(frame, (10, 125), (10 + int(200 * info["progress"]), 139), (0, 255, 0), -1)
                if info["hint"]:
                    cv2.putText(frame, info["hint"], (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            if now < flash_until:
                cv2.putText(frame, flash, (10, h - 60), cv2.FONT_HERSHEY_SIMPLEX, 1.0, flash_color, 3)
        else:
            seconds = time.time() - session_start
            pct = round(100 * correct / rounds_done) if rounds_done else 0
            frame[:] = (30, 30, 30)
            for i, line in enumerate(["Session finished", f"Correct: {correct} / {rounds_done}  ({pct}%)",
                                      f"Mistakes: {mistakes}   Skipped: {skipped}", f"Time: {int(seconds)} s",
                                      "", "Press any key to close"]):
                cv2.putText(frame, line, (30, 80 + i * 45), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
            if cv2.waitKey(1) & 0xFF != 255:
                break
        cv2.imshow("BCSignVR - letters and words", frame)
 
    cap.release()
    cv2.destroyAllWindows()
    if rounds_done:
        save_session(rounds_done, correct, skipped, mistakes, time.time() - session_start)
        print(f"Session saved to {SESSIONS_FILE}")
 
 
if __name__ == "__main__":
    main()
 