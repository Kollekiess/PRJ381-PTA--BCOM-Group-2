"""
serve_model.py  -  put the trained model behind a small web API, so the VR headset
can send hand positions over Wi-Fi and get the recognised letter back.
 
Setup (once):   pip install flask
Run (from the project root, after train.py):
    python serve_model.py
It prints the address to use in Unity, e.g.  http://192.168.1.20:5000
 
OPTIONAL password (recommended): set an environment variable before starting
    PowerShell:   $env:SIGN_API_KEY = "choose-a-long-secret"
and have the headset send it in the header  X-API-Key.
 
ENDPOINTS
  GET  /health    -> {"status": "ok", "letters": [...], "words": [...]}
  POST /predict   JSON body:
        {"points": [x0,y0, x1,y1, ... x20,y20]}      42 numbers: 21 landmarks, MediaPipe order,
                                                      x to the right, y pointing DOWN, no depth
        optional:  "target": "C"                      the letter the learner should sign
     (also accepted: {"points": [63 numbers x,y,z]} - the same layout as the CSV)
     Reply without target: {"letter": "C", "predicted": "C", "confidence": 0.97, "probabilities": [...]}
     Reply with target:    {"target": "C", "letter": "O", "predicted": "O", "confidence": 0.91,
                            "target_score": 0.03, "correct": false,
                            "message": "That looks like O, not C.",
                            "hint": "Straighten your index finger more."}
  POST /predict_word   (WORDS: a whole sign, i.e. a short clip of movement, one or two hands)
        {"clip": [...], "target": "HELLO"}      target is optional
        clip = frames one after another; each frame = LEFT hand then RIGHT hand, each hand =
        21 landmarks as x,y (MediaPipe order, x to the right, y DOWN). That is 84 numbers per frame
        (a hand that is not visible = 42 zeros). Send 8 to 300 frames (about 1 to 4 seconds);
        the server trims and resamples it. x,y are picture coordinates between 0 and 1.
     Reply: {"word": "HELLO", "predicted": "HELLO", "confidence": 0.93, "top": [...],
             and with a target: "target", "correct", "message"}
Only hand points are sent. No video or images ever leave the headset.
"""
 
import os
import socket
from threading import Lock
 
import numpy as np
from flask import Flask, jsonify, request
 
from ml.features import normalize_landmarks
from ml.feedback import FeedbackEngine
from ml.sequences import MIN_HAND_FRAMES, SEQ_LEN, resample, trim_empty_ends
from ml.word_model import classify_clip, load_word_model
 
PORT = 5000
API_KEY = os.environ.get("SIGN_API_KEY", "")
 
app = Flask(__name__)
engine = FeedbackEngine()
lock = Lock()
WORD_MODEL, WORD_LABELS = (None, [])
if os.path.isfile(os.path.join("models", "sasl_words_model.keras")):
    WORD_MODEL, WORD_LABELS = load_word_model()
WORD_MIN_CONF = 0.6
 
 
def to_flat63(values):
    v = np.asarray(values, dtype=float).flatten()
    if not np.all(np.isfinite(v)):
        raise ValueError("points contain NaN or infinity")
    if v.size == 42:
        out = np.zeros((21, 3))
        out[:, :2] = v.reshape(21, 2)
        return out.flatten()
    if v.size == 63:
        return v
    raise ValueError(f"send 42 numbers (x,y for 21 landmarks) or 63 (x,y,z); got {v.size}")
 
 
def to_clip(values):
    """Turn the flat list from the headset into a (30,126) clip like the ones collect_sequence.py saves."""
    v = np.asarray(values, dtype=float).flatten()
    if not np.all(np.isfinite(v)):
        raise ValueError("clip contains NaN or infinity")
    if v.size % 84 == 0:
        frames = v.reshape(-1, 2, 21, 2)
        clip = np.zeros((len(frames), 2, 21, 3))
        clip[..., :2] = frames
        clip = clip.reshape(len(frames), 126)
    elif v.size % 126 == 0:
        clip = v.reshape(-1, 126)
    else:
        raise ValueError("send frames of 84 numbers (2 hands x 21 points x x,y), or 126 (with z)")
    if not 8 <= len(clip) <= 300:
        raise ValueError(f"send between 8 and 300 frames; got {len(clip)}")
    frames = trim_empty_ends([f for f in clip.astype(np.float32)])
    if sum(1 for f in frames if np.any(f)) < MIN_HAND_FRAMES:
        raise ValueError("not enough frames with a hand visible")
    return resample(frames, SEQ_LEN)
 
 
@app.before_request
def check_key():
    if API_KEY and request.path != "/health" and request.headers.get("X-API-Key") != API_KEY:
        return jsonify(error="missing or wrong X-API-Key"), 401
 
 
@app.get("/health")
def health():
    return jsonify(status="ok", letters=engine.labels, words=[w for w in WORD_LABELS if w != "IDLE"])
 
 
@app.post("/predict")
def predict():
    data = request.get_json(silent=True)
    if not data or "points" not in data:
        return jsonify(error='send JSON like {"points": [42 numbers]}'), 400
    try:
        flat = to_flat63(data["points"])
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400
 
    target = data.get("target")
    with lock:
        if target:
            r = engine.evaluate(str(target), flat)
            return jsonify(target=r.target, letter=r.predicted, predicted=r.predicted,
                           confidence=r.confidence,
                           target_score=r.target_score, correct=r.correct,
                           message=r.message, hint=r.hint)
        feats = normalize_landmarks(flat).reshape(1, -1).astype("float32")
        probs = engine.model(feats, training=False).numpy()[0]
    best = int(np.argmax(probs))
    return jsonify(letter=engine.labels[best], predicted=engine.labels[best],
                   confidence=float(probs[best]),
                   probabilities=[float(p) for p in probs])
 
 
@app.post("/predict_word")
def predict_word():
    if WORD_MODEL is None:
        return jsonify(error="no word model yet: run train_sequence.py"), 503
    data = request.get_json(silent=True)
    if not data or "clip" not in data:
        return jsonify(error='send JSON like {"clip": [numbers]}'), 400
    try:
        clip = to_clip(data["clip"])
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400
    with lock:
        top = classify_clip(WORD_MODEL, WORD_LABELS, clip)
    best, conf = top[0]
    reply = dict(word=best, predicted=best, confidence=conf,
                 top=[dict(word=w, probability=p) for w, p in top])
    target = data.get("target")
    if target:
        target = str(target).upper()
        correct = best == target and conf >= WORD_MIN_CONF
        if correct:
            message = "Correct!"
        elif best == "IDLE" or conf < WORD_MIN_CONF:
            message = f"Not sure that was {target}. Try again."
        else:
            message = f"That looked like {best}, not {target}."
        reply.update(target=target, correct=correct, message=message)
    return jsonify(reply)
 
 
def my_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"
 
 
if __name__ == "__main__":
    print(f"\nSASL recognition API ready.  In Unity use:  http://{my_ip()}:{PORT}/predict")
    print("The headset and this computer must be on the SAME Wi-Fi network.")
    print("Words:", [w for w in WORD_LABELS if w != "IDLE"] or "none (run train_sequence.py)")
    print("Password protection:", "ON (X-API-Key)" if API_KEY else "OFF (set SIGN_API_KEY to turn on)")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
 