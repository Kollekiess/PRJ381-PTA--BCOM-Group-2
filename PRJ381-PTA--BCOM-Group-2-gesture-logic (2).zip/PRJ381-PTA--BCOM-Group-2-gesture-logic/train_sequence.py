import glob
import json
import os
 
import numpy as np
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow import keras
 
from ml.sequence_features import AUG_COPIES, FEATURES, SEQ_LEN, augment, clip_to_features, mirror_features
 
SEQ_DIR = os.path.join("data", "sequences")
MODEL_FILE = os.path.join("models", "sasl_words_model.keras")
LABELS_FILE = os.path.join("models", "sasl_words_labels.json")
REPORT_FILE = os.path.join("reports", "words_summary.txt")
MIN_CLIPS = 10
 
tf.random.set_seed(42)
rng = np.random.default_rng(42)
 
 
def build_model(num_words):
    return keras.Sequential([
        keras.layers.Input(shape=(SEQ_LEN, FEATURES)),
        keras.layers.Conv1D(48, 3, padding="same", activation="relu"),
        keras.layers.BatchNormalization(),
        keras.layers.GRU(64),
        keras.layers.Dropout(0.4),
        keras.layers.Dense(64, activation="relu"),
        keras.layers.Dense(num_words, activation="softmax"),
    ])
 
 
def load_clips():
    words = sorted(d for d in os.listdir(SEQ_DIR) if os.path.isdir(os.path.join(SEQ_DIR, d))) \
        if os.path.isdir(SEQ_DIR) else []
    data = {}
    for w in words:
        clips = []
        for p in sorted(glob.glob(os.path.join(SEQ_DIR, w, "clip_*.npy"))):
            c = np.load(p)
            if c.shape == (SEQ_LEN, 126):
                clips.append(c)
        data[w] = clips
    return data
 
 
def main():
    data = load_clips()
    if len(data) < 2:
        print("Need at least 2 words recorded in data/sequences. Use: python collect_sequence.py HELLO")
        return
    print("Clips per word:", {w: len(c) for w, c in data.items()})
    too_few = [w for w, c in data.items() if len(c) < MIN_CLIPS]
    if too_few:
        print(f"These words have fewer than {MIN_CLIPS} clips, record more first: {too_few}")
        return
 
    words = sorted(data)
    Xtr, ytr, Xva, yva, Xte, yte = [], [], [], [], [], []
    for label, w in enumerate(words):
        feats = [clip_to_features(c) for c in data[w]]
        n_test = max(2, round(0.2 * len(feats)))
        train, test = feats[:-n_test], feats[-n_test:]
        n_val = max(2, round(0.15 * len(train)))
        train, val = train[:-n_val], train[-n_val:]
        for F in train:                                   # originals + mirrored + jittered copies
            for base in (F, mirror_features(F)):
                Xtr.append(base); ytr.append(label)
                for _ in range(AUG_COPIES):
                    Xtr.append(augment(base, rng)); ytr.append(label)
        Xva += val; yva += [label] * len(val)
        Xte += test; yte += [label] * len(test)
    Xtr, ytr = np.array(Xtr), np.array(ytr)
    Xva, yva = np.array(Xva), np.array(yva)
    Xte, yte = np.array(Xte), np.array(yte)
    print(f"Training on {len(Xtr)} (with copies), checking on {len(Xva)}, testing on {len(Xte)} clips\n")
 
    model = build_model(len(words))
    model.compile(optimizer=keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.fit(Xtr, ytr, validation_data=(Xva, yva), epochs=80, batch_size=32, verbose=2,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=12,
                                                       restore_best_weights=True)])
 
    preds = np.argmax(model.predict(Xte, verbose=0), axis=1)
    acc = float(np.mean(preds == yte))
    report = classification_report(yte, preds, labels=range(len(words)), target_names=words, zero_division=0)
    cm = confusion_matrix(yte, preds, labels=range(len(words)))
    print(f"\nTest accuracy on clips the model never saw: {acc:.1%}\n")
    print(report)
    print("Confusion matrix (rows = true word, columns = predicted):")
    print(cm)
 
    os.makedirs("models", exist_ok=True)
    os.makedirs("reports", exist_ok=True)
    model.save(MODEL_FILE)
    with open(LABELS_FILE, "w") as f:
        json.dump(words, f)
    with open(REPORT_FILE, "w") as f:
        f.write(f"Words: {words}\nClips per word: {{{', '.join(f'{w}: {len(c)}' for w, c in data.items())}}}\n"
                f"Test clips: {len(Xte)}\nTest accuracy: {acc:.1%}\n\n{report}\nConfusion matrix:\n{cm}\n")
    print(f"\nSaved {MODEL_FILE}, {LABELS_FILE} and {REPORT_FILE}")
 
 
if __name__ == "__main__":
    main()
 